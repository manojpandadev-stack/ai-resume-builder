import axios from "axios";
import { useState } from "react";

function App() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    education: "",
    skills: "",
    experience: "",
    projects: "",
  });

  const [resume, setResume] = useState("");
  const [analysis, setAnalysis] = useState("");
  const [coverLetter, setCoverLetter] = useState("");

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const generateResume = async () => {
    try {
      const response = await axios.post(
        "http://localhost:8080/ai/generate",
        form
      );
      setResume(response.data);
    } catch (error) {
      console.error(error);
      alert("Error generating resume");
    }
  };

  const analyzeResume = async () => {
    try {
      const response = await axios.post(
        "http://localhost:8080/ai/analyze",
        resume,
        {
          headers: {
            "Content-Type": "text/plain",
          },
        }
      );
      setAnalysis(response.data);
    } catch (error) {
      console.error(error);
      alert("Error analyzing resume");
    }
  };

  const generateCoverLetter = async () => {
    try {
      const response = await axios.post(
        "http://localhost:8080/ai/cover-letter",
        form
      );
      setCoverLetter(response.data);
    } catch (error) {
      console.error(error);
      alert("Error generating cover letter");
    }
  };

  const downloadPdf = async () => {
    try {
      const response = await axios.post(
        "http://localhost:8080/pdf/download",
        resume,
        {
          headers: {
            "Content-Type": "text/plain",
          },
          responseType: "blob",
        }
      );

      const url = window.URL.createObjectURL(response.data);
      const link = document.createElement("a");

      link.href = url;
      link.setAttribute("download", "resume.pdf");

      document.body.appendChild(link);
      link.click();
      link.remove();

      window.URL.revokeObjectURL(url);
    }catch (error) {
  console.log(error);

  alert(error.message);
}
  alert("Status: " + error.response?.status);
}
  };

  return (
    <div style={{ padding: "30px" }}>
      <h1>🤖 AI Resume Builder</h1>

      <input
        type="text"
        name="name"
        placeholder="Name"
        onChange={handleChange}
      />
      <br /><br />

      <input
        type="email"
        name="email"
        placeholder="Email"
        onChange={handleChange}
      />
      <br /><br />

      <input
        type="text"
        name="phone"
        placeholder="Phone"
        onChange={handleChange}
      />
      <br /><br />

      <textarea
        name="education"
        placeholder="Education"
        onChange={handleChange}
      />
      <br /><br />

      <textarea
        name="skills"
        placeholder="Skills"
        onChange={handleChange}
      />
      <br /><br />

      <textarea
        name="experience"
        placeholder="Experience"
        onChange={handleChange}
      />
      <br /><br />

      <textarea
        name="projects"
        placeholder="Projects"
        onChange={handleChange}
      />
      <br /><br />

      <button onClick={generateResume}>
        Generate Resume
      </button>

      <button
        onClick={analyzeResume}
        style={{ marginLeft: "10px" }}
      >
        Analyze Resume
      </button>

      <button
        onClick={generateCoverLetter}
        style={{ marginLeft: "10px" }}
      >
        Cover Letter
      </button>

      <button
        onClick={downloadPdf}
        style={{ marginLeft: "10px" }}
      >
        Download PDF
      </button>

      <hr />

      <h2>Generated Resume</h2>
      <pre
        style={{
          whiteSpace: "pre-wrap",
          background: "#f4f4f4",
          padding: "20px",
          borderRadius: "10px",
        }}
      >
        {resume}
      </pre>

      <h2>ATS Analysis</h2>
      <pre
        style={{
          whiteSpace: "pre-wrap",
          background: "#eef6ff",
          padding: "20px",
          borderRadius: "10px",
        }}
      >
        {analysis}
      </pre>

      <h2>Cover Letter</h2>
      <pre
        style={{
          whiteSpace: "pre-wrap",
          background: "#fff8e1",
          padding: "20px",
          borderRadius: "10px",
        }}
      >
        {coverLetter}
      </pre>
    </div>
  );
}

export default App;